package com.example.matrimonyjetpack.mvvm.viewModel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.matrimonyjetpack.mvvm.model.Profile
import com.example.matrimonyjetpack.mvvm.repository.HomeRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = HomeRepository(application)

    private val _profiles = MutableStateFlow<List<Profile>>(emptyList())
    val profiles: StateFlow<List<Profile>> = _profiles

    init {
        loadProfile()
    }

    private fun loadProfile() {
        viewModelScope.launch {
            _profiles.value = repository.getProfiles()
            Log.d("RoomDB", "Profiles loaded into ViewModel: ${_profiles.value}")
        }
    }

    fun removeProfile(profile: Profile) {
        _profiles.value = _profiles.value.filter { it != profile }
    }

}