package com.example.matrimonyjetpack.mvvm.viewModel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.matrimonyjetpack.R
//import com.example.matrimonyjetpack.mvvm.model.ProfileEntity
import com.example.matrimonyjetpack.mvvm.repository.GestureRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class GestureViewModel(application: Application) : AndroidViewModel(application) {

}