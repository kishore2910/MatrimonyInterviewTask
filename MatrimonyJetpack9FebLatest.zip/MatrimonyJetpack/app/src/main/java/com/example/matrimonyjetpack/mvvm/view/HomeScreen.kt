package com.example.matrimonyjetpack.mvvm.view

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.matrimonyjetpack.R
import com.example.matrimonyjetpack.mvvm.model.Profile
import com.example.matrimonyjetpack.mvvm.viewModel.HomeViewModel

@Composable
fun HomeScreen(navController: NavController, homeViewModel: HomeViewModel =  viewModel()){

    val profilesDB by homeViewModel.profiles.collectAsState()
//    val profiles = listOf(
//        Profile(0,"Priyanka",27,"5 ft 2 in", "Tamil", "Nair", "MBBS, Doctor", "Chennai", "Tamil Nadu", R.drawable.profile1),
//        Profile(0,"Aiswarya", 26, "5 ft 2 in", "Tamil", "Nair", "MBBS, Doctor", "Chennai", "Tamil Nadu", R.drawable.profile2),
//        Profile(0,"Raj",27,"5 ft 2 in", "Tamil", "Nair", "MBBS, Doctor", "Chennai", "Tamil Nadu", R.drawable.profile3),
//        Profile(0,"Deepak",27,"5 ft 2 in", "Tamil", "Nair", "MBBS, Doctor", "Chennai", "Tamil Nadu", R.drawable.profile4),
//        Profile(0,"Aaron",27,"5 ft 2 in", "Tamil", "Nair", "MBBS, Doctor", "Chennai", "Tamil Nadu", R.drawable.profile5),
//    )

    Column (modifier = Modifier
        .fillMaxSize()
        .background(Color(0xFF2196F3))){
        TopBar(navController)
        TitleSection()
        ProfileList(profilesDB,navController,homeViewModel)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopBar(navController: NavController) {
    ConstraintLayout(
    ) {
        // Create references for constraints
        val (menuIcon, titleText) = createRefs()

        // Menu Icon
        Image(
            painter = painterResource(id = R.drawable.baseline_menu_24),
            contentDescription = "Menu Icon",
            modifier = Modifier
                .clickable {
                    navController.navigate("gesture")
                }
                .constrainAs(menuIcon) {
                    end.linkTo(parent.end, margin = 36.dp)
                    top.linkTo(parent.top, margin = 57.dp)
                    start.linkTo(titleText.end, margin = 240.dp)
                }
        )

        // Sample Text (Optional)
        Text(
            text = "My Matches",
            fontSize = 20.sp,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.constrainAs(titleText) {
                start.linkTo(parent.start, margin = 30.dp)  // Align text to the start
                top.linkTo(parent.top, margin = 60.dp)     // Align text slightly below top
            }
        )
    }
}

@Composable
fun ProfileList(profiles: List<Profile>, navController: NavController, viewModel: HomeViewModel) {
//    ConstraintLayout {
//        val cardLazy = createRefs()

    if (profiles.isEmpty()){
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(15.dp),
            contentAlignment = androidx.compose.ui.Alignment.Center // Center Text
        ) {
            Text(
                text = "No profiles available!",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }else{
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 18.dp)
//                .constrainAs(cardLazy){
//                    top.linkTo(parent.top, margin = 30.dp ) }
            ,
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(profiles) { profile ->
                ProfileCard(profile, navController,viewModel)
            }
        }
    }

//    }

}
@Composable
fun TitleSection() {

        Row(modifier = Modifier
            .padding(16.dp)
        ) {
            ConstraintLayout {
                val (pendingText , newText) = createRefs()

            Text(text = "8 Profiles pending with me",
                fontSize = 24.sp,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.constrainAs(pendingText){
                    start.linkTo(parent.start, margin = 14.dp)
                    top.linkTo(parent.top, margin = 30.dp)
                }
            )
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .constrainAs(newText) {
                        start.linkTo(pendingText.end, margin = 2.dp)
                        top.linkTo(parent.top, margin = 30.dp)
                    }
                    .background(color = Color(0xFF2196F3), shape = RoundedCornerShape(12.dp))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
                    .height(24.dp)
                    .width(60.dp)
                    .border(width = 1.dp, color = Color.White, shape = RoundedCornerShape(23.dp))
            ) {
                Text(
                    modifier = Modifier
                        .padding(start = 10.dp)
                    , text = "5 NEW",
                    fontSize = 12.sp,
                    color = Color.White,)

            }
            }

        }


}

@Composable
fun ProfileCard(profile: Profile, navController: NavController, homeViewModel: HomeViewModel) {
    Card(
        modifier = Modifier
            .width(210.dp)
            .height(310.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFFDFD)),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 10.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = profile.imageRes),
                contentDescription = profile.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .height(160.dp)
                    .fillMaxWidth()
                    .clickable {
                        navController.navigate("details")
                    }
            )
            Column(modifier = Modifier
                .padding(top = 10.dp)
                .clickable {
                    navController.navigate("details")
                }) {
                Text(
                    modifier = Modifier.padding(start = 13.dp),
                    text = profile.name,
                    fontSize = 16.sp,
                    color = Color.Black,
                    fontWeight = FontWeight.SemiBold)
                Text(
                    modifier = Modifier.padding(start = 13.dp),
                    text = "${profile.age} Yrs, " +
                            "${profile.height}, " +
                            "${profile.language}," +
                            " ${profile.caste}",
                    color = Color.Black,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    modifier = Modifier.padding(start = 13.dp),
                    text = "${profile.profession}," +
                        " ${profile.city}," +
                        " ${profile.state}",
                    color = Color.Black,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.SemiBold
                    )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    val context = LocalContext.current
                    Button(
                        modifier = Modifier.padding(top = 3.dp),
                        onClick = {
                            Toast.makeText(context, "Profile Accepted", Toast.LENGTH_SHORT).show()

                            homeViewModel.removeProfile(profile)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFA000))
                    ) {
                        Text(text = "Yes", color = Color.White,)
                    }
                    Button(
                        modifier = Modifier.padding(end = 20.dp, top = 3.dp),
                        onClick = {
                            Toast.makeText(context, "Profile Rejected", Toast.LENGTH_SHORT).show()

                            homeViewModel.removeProfile(profile)
                        },
                        border = BorderStroke(0.5.dp, Color.Black),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFFFF))
                    ) {
                        Text(text = "No", color = Color.Black)
                    }
                }
            }
        }
    }
}

@Preview
@Composable
fun HomeScreenPreviewScreen(){
//    HomeScreen()
}


