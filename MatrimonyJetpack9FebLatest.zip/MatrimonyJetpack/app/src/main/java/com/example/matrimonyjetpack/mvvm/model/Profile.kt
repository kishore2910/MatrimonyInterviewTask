package com.example.matrimonyjetpack.mvvm.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "profile_database")
data class Profile @JvmOverloads constructor(
    @PrimaryKey(autoGenerate = true)
    val id : Int = 0,
    val name : String,
    val age: Int,
    val height: String,
    val language: String,
    val caste: String,
    val profession: String,
    val city: String,
    val state: String,
    val imageRes: Int
){
    constructor() : this(0, "", 0, "", "", "", "", "", "", 0)
}

