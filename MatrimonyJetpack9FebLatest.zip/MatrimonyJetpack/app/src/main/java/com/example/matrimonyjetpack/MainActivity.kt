package com.example.matrimonyjetpack

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.matrimonyjetpack.mvvm.model.Profile
import com.example.matrimonyjetpack.mvvm.room.AppDatabase
import com.example.matrimonyjetpack.mvvm.view.HomeScreen
import com.example.matrimonyjetpack.mvvm.view.ProfileCardScreen
import com.example.matrimonyjetpack.mvvm.view.ProfileDetailScreen
import com.example.matrimonyjetpack.mvvm.viewModel.HomeViewModel
import com.example.matrimonyjetpack.ui.theme.MatrimonyJetpackTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MatrimonyJetpackTheme {
//                    HomeScreen()
                    MyAppNavigation()
//                populateDatabase(this)
//                CardStackScreen()
//                ProfileCardScreen()
//                ProfileDetailScreen()
            }
        }
    }
}

@Composable
fun MyAppNavigation(){
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "home") {
        composable("home"){ HomeScreen(navController) }
        composable("gesture"){ ProfileCardScreen(navController) }
        composable("details"){ ProfileDetailScreen(navController)}
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    MatrimonyJetpackTheme {
//        HomeScreen()
    }
}