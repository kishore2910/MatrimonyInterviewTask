package com.example.matrimonyjetpack.mvvm.view

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.matrimonyjetpack.R
import com.example.matrimonyjetpack.mvvm.model.Profile
import com.example.matrimonyjetpack.mvvm.viewModel.HomeViewModel
import kotlinx.coroutines.launch

@Composable
fun ProfileCardScreen(navController: NavController, homeViewModel: HomeViewModel = viewModel()) {
    val profilesDB by homeViewModel.profiles.collectAsState()
    val profileStack = remember { mutableStateListOf<Profile>() }

    LaunchedEffect(profilesDB) {
        profileStack.clear()
        profileStack.addAll(profilesDB)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(colors = listOf(Color(0xFF52B976), Color.White))
            )
    ) {
        TopGestureBar(navController)

        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            if (profileStack.isEmpty()) {
                Text(
                    text = "No profiles available",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
            profileStack.take(3).reversed().forEachIndexed { index, profile ->
                SwipeableCard(
                    profile = profile,
                    onSwiped = { profileStack.remove(profile) },
                    isTopCard = index == profileStack.lastIndex
                )
            }
        }
    }
}

@Composable
fun SwipeableCard(
    profile: Profile,
    onSwiped: () -> Unit,
    isTopCard: Boolean,
    homeViewModel: HomeViewModel = viewModel()
) {
    var offsetX by remember { mutableStateOf(0f) }
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(500.dp)
            .offset { IntOffset(offsetX.toInt(), 0) }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = {
                        if (offsetX > 300 || offsetX < -300) {
                            coroutineScope.launch {
                                onSwiped()
                                offsetX = 0f
                            }
                        } else {
                            offsetX = 0f
                        }
                    }
                ) { change, dragAmount ->
                    change.consume()
                    offsetX += dragAmount.x
                }
            }
    ) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = if (isTopCard) 12.dp else 4.dp),
            modifier = Modifier
//                .fillMaxWidth()
                .height(520.dp)
//                .padding(12.dp)
                .offset(y = if (isTopCard) 0.dp else (10 * (3 - profile.id)).dp) // Stack effect
        ) {
            Column {
                Image(
                    painter = painterResource(id = profile.imageRes),
                    contentDescription = "Profile Image",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                )
                Column(modifier = Modifier.padding(start = 12.dp, top = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
//                        Image(painter = painterResource(id = R.drawable.verified), contentDescription = "")
                        Text(text = "Verified", color = Color(0xFF2196F3)) // Blue
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Premium NRI", color = Color(0xFF9C27B0)) // Purple
                    }
                    Spacer(modifier = Modifier.height(3.dp))

                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = profile.name,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "27 Yrs, 5 ft 5 in, MBBS, Doctor, Chennai, Tamil Nadu.",
                            fontSize = 18.sp,
                            color = Color.DarkGray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                Divider(color = Color.LightGray, thickness = 0.9.dp)

                // Bottom Actions
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        modifier = Modifier.padding(start = 5.dp),
                        painter = painterResource(id = R.drawable.baseline_star_border_24),
                        contentDescription = "star"
                    )

                    Text(
                        modifier = Modifier.padding(end = 70.dp),
                        text = "Shortlist",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.DarkGray
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            modifier = Modifier.padding(end = 25.dp),
                            text = "Like her?",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )

                        val context = LocalContext.current
                        Button(
                            modifier = Modifier
//                                .size(50.dp)
                                .offset(x = -20.dp)
                                .padding(end = 7.dp),
                            onClick = {
                                onSwiped()
                                homeViewModel.removeProfile(profile)
                                Toast.makeText(context, "Profile Rejected", Toast.LENGTH_SHORT)
                                    .show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                            border = BorderStroke(0.7.dp, Color.Black)
                        ) {
                            Text("X",
                                fontSize = 20.sp,
                                color = Color.Black,)
                        }

//                        Spacer(modifier = Modifier.width(10.dp))
                        Button(
                            modifier = Modifier
                                .offset(x = -20.dp)
//                                .size(50.dp)
                            ,
                            onClick = {
                                onSwiped()
                                homeViewModel.removeProfile(profile)
                                Toast.makeText(context, "Profile Accepted", Toast.LENGTH_SHORT)
                                    .show()

                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFA000)),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("✔",
                                fontSize = 20.sp,
                                )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopGestureBar(navController: NavController) {
    TopAppBar(
        title = { Text(text = "Daily Recommendations", color = Color.White) },
        navigationIcon = {
            IconButton(onClick = { navController.navigate("home") }) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF52B976))
    )
}

@Preview(showBackground = true)
@Composable
fun PreviewProfileCard() {
//    ProfileCardScreen()
}
