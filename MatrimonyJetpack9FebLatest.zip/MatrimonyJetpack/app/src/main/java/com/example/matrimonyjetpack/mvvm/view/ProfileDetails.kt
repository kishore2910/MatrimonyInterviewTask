package com.example.matrimonyjetpack.mvvm.view

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.navigation.NavController
import com.example.matrimonyjetpack.R
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileDetailScreen(navController: NavController) {
    val images = listOf(
        R.drawable.profile1,
        R.drawable.profile2,
        R.drawable.profile3,
        R.drawable.profile4,
        R.drawable.profile5,
    )
    val listState = rememberLazyListState()
    val currentPage by  remember { derivedStateOf { listState.firstVisibleItemIndex + 1} }

    ConstraintLayout {
        val codeText = createRef()
        Text(modifier = Modifier.constrainAs(codeText){
            start.linkTo(parent.start, margin = 35.dp)
            top.linkTo(parent.top, margin = 25.dp)
        },
            text = "M9837832",
            color = Color.Black)

        IconButton(onClick = {
            navController.navigate("home")
        }) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.Black)
        }
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(text = "M9837832",
                    color = Color.Black) },
                navigationIcon = {
                    IconButton(onClick = {
                        navController.navigate("home")
                    }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.Black)
                    }
                },
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
                .padding(paddingValues)
        ) {


                ImagePager(images,currentPage, listState)

                ProfileDetails(currentPage + 1 , images.size)

        }
    }
}

@Composable
fun ImagePager(images: List<Int>, currentPage: Int, listState: LazyListState) {

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(modifier = Modifier.fillMaxWidth()) {
            androidx.compose.foundation.lazy.LazyRow(
                state = listState,
            ) {
                items(images.size) { index ->
                    Image(
                        painter = painterResource(id = images[index]),
                        contentDescription = "Profile Image",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(300.dp)
                    )
                }
            }

            // Image Counter (Top Right Corner)
            Text(
                text = "${listState.firstVisibleItemIndex + 1}/${images.size}",
                fontSize = 14.sp,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
                    .background(Color.Black.copy(alpha = 0.5f), shape = RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            images.forEachIndexed { index, _ ->
                Box(
                    modifier = Modifier
                        .size(if (index == currentPage - 1) 10.dp else 6.dp) // Active Dot is Bigger
                        .background(
                            if (index == currentPage - 1) Color.Blue else Color.Gray,
                            shape = RoundedCornerShape(50)
                        )
                        .padding(horizontal = 4.dp)
                )
                Spacer(modifier = Modifier.width(5.dp))
            }
        }
    }
}

@Composable
fun ProfileDetails(currentImage: Int, totalImages: Int) {
    Card(
        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
        modifier = Modifier.fillMaxSize(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 16.dp)

    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text(
                text = "Priyanka",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "27 Yrs, 5 ft 2 in, Tamil, Nair, MBBS, Doctor, Chennai, Tamil Nadu, India.",
                fontSize = 14.sp,
                color = Color.Gray
            )
            Divider(modifier = Modifier.padding(top = 7.dp), color = Color.LightGray, thickness = 0.9.dp)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewProfileDetailScreen() {
//    ProfileDetailScreen()
}