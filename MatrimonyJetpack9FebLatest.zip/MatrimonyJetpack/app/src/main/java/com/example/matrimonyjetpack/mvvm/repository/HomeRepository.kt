package com.example.matrimonyjetpack.mvvm.repository

import android.content.Context
import android.util.Log
import com.example.matrimonyjetpack.R
import com.example.matrimonyjetpack.mvvm.model.Profile
import com.example.matrimonyjetpack.mvvm.room.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class HomeRepository(private val context: Context) {

    private val profileDao = AppDatabase.getDatabase(context).profileDao()

    suspend fun getProfiles(): List<Profile> {
        return withContext(Dispatchers.IO) {
            val profiles = profileDao.getAllProfile()
            if (profiles.isEmpty()) {
                Log.d("RoomDB", "Database is empty. Inserting default profiles.")
                val defaultProfiles = listOf(
                    Profile(
                        1,
                        "Priyanka",
                        27,
                        "5 ft 2 in",
                        "Tamil",
                        "Nair",
                        "MBBS, Doctor",
                        "Chennai",
                        "Tamil Nadu",
                        R.drawable.profile1
                    ),
                    Profile(
                        2,
                        "Aiswarya",
                        26,
                        "5 ft 2 in",
                        "Tamil",
                        "Nair",
                        "MBBS, Doctor",
                        "Chennai",
                        "Tamil Nadu",
                        R.drawable.profile2
                    ),
                    Profile(
                        3,
                        "Raj",
                        27,
                        "5 ft 2 in",
                        "Tamil",
                        "Nair",
                        "MBBS, Doctor",
                        "Chennai",
                        "Tamil Nadu",
                        R.drawable.profile3
                    ),
                    Profile(
                        4,
                        "Deepak",
                        27,
                        "5 ft 2 in",
                        "Tamil",
                        "Nair",
                        "MBBS, Doctor",
                        "Chennai",
                        "Tamil Nadu",
                        R.drawable.profile4
                    ),
                    Profile(
                        5,
                        "Aaron",
                        27,
                        "5 ft 2 in",
                        "Tamil",
                        "Nair",
                        "MBBS, Doctor",
                        "Chennai",
                        "Tamil Nadu",
                        R.drawable.profile5
                    )
                )
                profileDao.insertProfile(defaultProfiles)
                Log.d("RoomDB", "Inserted default profiles into Room DB.")
                defaultProfiles
            } else {
                Log.d("RoomDB", "Fetched profiles from Room DB: $profiles")
                profiles
            }
        }
    }
}
