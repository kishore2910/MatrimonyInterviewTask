package com.example.matrimonyjetpack.mvvm.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.matrimonyjetpack.mvvm.model.Profile

@Dao
interface ProfileDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProfile(profile: List<Profile>)

    @Query("SELECT * FROM profile_database")
    suspend fun getAllProfile(): List<Profile>

    @Query("SELECT * FROM profile_database WHERE id = :profileId")
    suspend fun getProfileById(profileId: Int): Profile?

}