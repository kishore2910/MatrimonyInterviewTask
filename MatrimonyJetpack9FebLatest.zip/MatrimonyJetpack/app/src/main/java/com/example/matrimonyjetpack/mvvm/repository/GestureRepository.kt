package com.example.matrimonyjetpack.mvvm.repository

import android.content.Context
import com.example.matrimonyjetpack.R
import com.example.matrimonyjetpack.mvvm.model.Profile
import com.example.matrimonyjetpack.mvvm.room.ProfileDao
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

class GestureRepository(private val profileDao : ProfileDao) {

//    val profiles: Flow<List<ProfileEntity>> = profileDao.getProfiles()
//
//    suspend fun insertProfiles(profiles: List<ProfileEntity>) {
//        profileDao.insertProfiles(profiles)
//    }

}
